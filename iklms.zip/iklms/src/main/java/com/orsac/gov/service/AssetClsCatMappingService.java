/*
package com.orsac.gov.service;

import com.orsac.gov.model.AssetClsCatMapping;
import com.orsac.gov.model.AssetMCategory;
import com.orsac.gov.repository.AssetClsCatMappingRepository;
import com.orsac.gov.repository.AssetMCategoryRepository;
import com.orsac.gov.repository.AssetMClassRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AssetClsCatMappingService {
    @Autowired
    private AssetClsCatMappingRepository assetClsCatMappingrepository;

    public void insertAssetClassCatData(AssetClsCatMapping assetClsCatMapping) {
        assetClsCatMappingrepository.save(assetClsCatMapping);
    }

}
*/
