package com.orsac.gov.controller;

import com.orsac.gov.model.AssetMClass;
import com.orsac.gov.service.AssetMClassServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;

@RestController
public class AssetMClassController {
    @Autowired
    private AssetMClassServices assetMClassServices;

    @PostMapping("/saveAssetMClass")
    public ResponseEntity<AssetMClass> saveAssetMClass(@RequestBody AssetMClass assetMClass) {
        assetMClass.setCreatedOn(new Date(System.currentTimeMillis()));
        assetMClass.setUpdatedOn(new Date(System.currentTimeMillis()));
        assetMClassServices.saveAssetMClass(assetMClass);
        return new ResponseEntity<AssetMClass>(HttpStatus.CREATED);
    }

    @GetMapping("/getAllAssetMClass")
    public List<AssetMClass> getAllAssetMClass() {
        return assetMClassServices.getAllAssetMClass();

    }

    @PutMapping("/updateAssetMClassById/{id}")
    public ResponseEntity<AssetMClass> updateCircleById(@RequestBody AssetMClass assetMClass, @PathVariable("id") int id) {
        try {
            AssetMClass asset = assetMClassServices.assetMClassGetById(id);
            asset.setUpdatedOn(new Date(System.currentTimeMillis()));
            asset.setNameE(assetMClass.getNameE());
            asset.setNameO(assetMClass.getNameO());
            asset.setUpdatedBy(assetMClass.getUpdatedBy());
            asset.setCreatedBy(assetMClass.getCreatedBy());
            assetMClassServices.saveAssetMClass(asset);
            return new ResponseEntity<AssetMClass>(HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<AssetMClass>(HttpStatus.NOT_FOUND);
        }
    }

}
