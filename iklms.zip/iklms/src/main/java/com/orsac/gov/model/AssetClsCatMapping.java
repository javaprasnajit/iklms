package com.orsac.gov.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "asset_cls_cat_mapping")
public class AssetClsCatMapping {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "id", nullable = false, unique = true)
    private int id;
    private Boolean isActive = true;
    private int createdBy;
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdOn;
    private int updatedBy;
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedOn;


   /* @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "class_id")
    private AssetMClass assetMClass;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id")
    private AssetMCategory assetMCategory;*/


}
