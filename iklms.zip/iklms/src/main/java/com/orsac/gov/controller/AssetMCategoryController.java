/*
package com.orsac.gov.controller;

import com.orsac.gov.model.AssetAttributes;
import com.orsac.gov.model.AssetMCategory;
import com.orsac.gov.service.AssetMCategoryServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;

@RestController
public class AssetMCategoryController {
    @Autowired
    private AssetMCategoryServices assetMCategoryServices;

    @PostMapping("/saveAssetMCategory")
    public ResponseEntity<AssetMCategory> saveAssetMCategory(@RequestBody AssetMCategory assetMCategory) {
//        assetMCategory.setCreatedOn(new Date(System.currentTimeMillis()));
//        assetMCategory.setUpdatedOn(new Date(System.currentTimeMillis()));
        assetMCategoryServices.saveAssetMCategory(assetMCategory);
        return new ResponseEntity<AssetMCategory>(HttpStatus.CREATED);
    }

    @GetMapping("/getAllAssetMCategory")
    public List<AssetMCategory> getAllAsset() {
        return assetMCategoryServices.getAssetMCategory();

    }


}
*/
