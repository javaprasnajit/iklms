/*
package com.orsac.gov.controller;

import com.orsac.gov.model.AssetAttributes;
import com.orsac.gov.model.AssetClsCatMapping;
import com.orsac.gov.service.AssetAttributesService;
import com.orsac.gov.service.AssetClsCatMappingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@RestController
public class AssetAttributesController {
    @Autowired
    private AssetAttributesService assetAttributesService;

    @PostMapping("/saveAsset")
    public ResponseEntity<AssetAttributes> saveAsset(@RequestBody AssetAttributes assetAttributes) {
        assetAttributes.setCreatedOn(new Date(System.currentTimeMillis()));
        //assetAttributes.setUpdatedOn(new Date(System.currentTimeMillis()));
        assetAttributesService.saveAsset(assetAttributes);
        return new ResponseEntity<AssetAttributes>(HttpStatus.CREATED);
    }

    @GetMapping("/getAllAsset")
    public List<AssetAttributes> getAllAsset() {
        return assetAttributesService.getAllAsset();

    }

    @GetMapping("/getAssetById/{id}")
    public ResponseEntity<AssetAttributes> getCircleById(@PathVariable("id") int assetId) {
        try {
            AssetAttributes assetAttributes = assetAttributesService.getById(assetId);
            return new ResponseEntity<AssetAttributes>(assetAttributes, HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<AssetAttributes>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/updateAssetById/{id}")
    public ResponseEntity<AssetAttributes> updateCircleById(@RequestBody AssetAttributes assetAttributes, @PathVariable("id") int assetId) {
        try {
           AssetAttributes asset = assetAttributesService.getById(assetId);
            asset.setUpdatedOn(new Date(System.currentTimeMillis()));
            asset.setLabEngaged(assetAttributes.getLabEngaged());
            asset.setAreaCovered(assetAttributes.getAreaCovered());
            asset.setHeight(assetAttributes.getHeight());
            asset.setLength(assetAttributes.getLength());
            asset.setManDayWork(assetAttributes.getManDayWork());
            asset.setCreatedBy(assetAttributes.getCreatedBy());
            assetAttributesService.saveAsset(asset);
            return new ResponseEntity<AssetAttributes>(HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<AssetAttributes>(HttpStatus.NOT_FOUND);
        }
    }


    @DeleteMapping("/deleteAssetById/{id}")
    public void deleteCircleById(@PathVariable("id") int assetId) {
        assetAttributesService.delete(assetId);
    }
}
*/
