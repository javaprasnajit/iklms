package com.orsac.gov.repository;


import com.orsac.gov.model.AssetClsCatMapping;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface AssetClsCatMappingRepository extends JpaRepository<AssetClsCatMapping, Integer> {

    Optional<AssetClsCatMapping> findById(Integer id);
    void deleteById(Integer id);

}
