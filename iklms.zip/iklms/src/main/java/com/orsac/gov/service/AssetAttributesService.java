package com.orsac.gov.service;

import com.orsac.gov.model.AssetAttributes;
import com.orsac.gov.repository.AssetAttributesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AssetAttributesService {
    @Autowired
    private AssetAttributesRepository assetAttributesRepository;

    public AssetAttributes saveAsset(AssetAttributes assetAttributes) {
        return assetAttributesRepository.save(assetAttributes);
    }

    public List<AssetAttributes> getAllAsset() {
        return assetAttributesRepository.findAll();
    }

    public AssetAttributes getById(int assetId) {
        return assetAttributesRepository.findById(assetId).get();
    }

    public void delete(Integer assetId) {
        assetAttributesRepository.deleteById(assetId);
    }
}
