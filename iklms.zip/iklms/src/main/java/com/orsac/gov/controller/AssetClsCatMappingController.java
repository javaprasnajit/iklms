package com.orsac.gov.controller;

import com.orsac.gov.model.AssetClsCatMapping;
import com.orsac.gov.model.AssetMCategory;
import com.orsac.gov.service.AssetClsCatMappingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

@RestController
public class AssetClsCatMappingController {

    @Autowired
    private AssetClsCatMappingService assetClsCatMappingService;

    @PostMapping("/saveAssetClassCat")
    public ResponseEntity<AssetClsCatMapping> saveAssetClassCat(@RequestBody AssetClsCatMapping assetClsCatMapping) {
        assetClsCatMapping.setCreatedOn(new Date(System.currentTimeMillis()));
        assetClsCatMapping.setUpdatedOn(new Date(System.currentTimeMillis()));
        assetClsCatMappingService.insertAssetClassCatData(assetClsCatMapping);
        return new ResponseEntity<AssetClsCatMapping>(HttpStatus.CREATED);


    }


}
