/*
package com.orsac.gov.service;

import com.orsac.gov.model.AssetMCategory;
import com.orsac.gov.repository.AssetMCategoryRepository;
import com.orsac.gov.repository.AssetMClassRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AssetMCategoryServices {

    @Autowired
    private AssetMCategoryRepository assetMCategoryRepository;
    @Autowired
    private AssetMClassRepository assetMClassRepository;


    public void saveAssetMCategory(AssetMCategory assetMCategory) {
        assetMCategoryRepository.save(assetMCategory);

    }

    public List<AssetMCategory> getAssetMCategory() {
        return assetMCategoryRepository.findAll();
    }
}
*/
