package com.orsac.gov.model;

import lombok.*;

import javax.persistence.*;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "asset_m_class")
public class AssetMClass {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private int id;
   // @Column(name="name_e",nullable = false, unique = true)
    private String nameE;
    private String nameO;
    private int createdBy;
    private Date createdOn;
    private int updatedBy;
    private Date updatedOn;
    private Boolean isActive=false;

}
