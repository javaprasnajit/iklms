package com.orsac.gov.model;

import lombok.*;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "asset_mt_class")
public class AssetMClass {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column(name="name_e",nullable = false, unique = true)
    private String nameE;

    @Column(name="name_o")
    private String nameO;

    @Column(name="int_created_by")
    private Integer createdBy;

    @Column(name="int_updated_by")
    private Integer updatedBy;

    @Column(name="dtm_created_on")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdOn;

    @Column(name="dtm_updated_on")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedOn;

    private Boolean isActive=true;


}
