/*
package com.orsac.gov.repository;

import com.orsac.gov.model.AssetAttributes;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
@Repository
public interface AssetAttributesRepository extends JpaRepository<AssetAttributes, Integer> {
    Optional<AssetAttributes> findById(Integer assetId);
    void deleteById(Integer assetId);

}
*/
