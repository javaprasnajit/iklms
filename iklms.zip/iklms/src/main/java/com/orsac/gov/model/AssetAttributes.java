package com.orsac.gov.model;

import lombok.*;
import org.springframework.data.annotation.CreatedDate;

import javax.persistence.*;
import java.util.Date;

@Data
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="asset_attributes")
public class AssetAttributes {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name="asset_id",nullable = false, unique = true)
    private int assetId;
    private String measurementUnit1;
    private int measurementVal1;
    private String measurementUnit2;
    private int measurementVal2;
    private String measurementUnit3;
    private int measurementVal3;
    private int length;
    private int width;
    private int height;
    private int manDayWork;
    private int labEngaged;
    private int areaCovered;
    private int createdBy;
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdOn;
    private int updatedBy;
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedOn;

}
