package com.orsac.gov.service;

import com.orsac.gov.model.AssetMClass;
import com.orsac.gov.repository.AssetMClassRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.ClientInfoStatus;
import java.util.List;

@Service
public class AssetMClassServices {

    @Autowired
    private AssetMClassRepository assetMClassRepository;


    public void saveAssetMClass(AssetMClass assetMClass) {
       assetMClassRepository.save(assetMClass);
    }

    public List<AssetMClass> getAllAssetMClass() {
        return assetMClassRepository.findAll();
    }

    public AssetMClass assetMClassGetById(int id) {
        return assetMClassRepository.findById(id).get();
    }


}

    /*public void delete(Integer assetId) {
        assetMClassRepository.deleteById(assetId);
    }*/


