create sequence hibernate_sequence start 1 increment 1
create table asset_mt_class (id int4 not null, name_e varchar(255) not null, primary key (id))
alter table if exists asset_mt_class add constraint UK_oepqnoc5agox1t2m1ya000h84 unique (name_e)
